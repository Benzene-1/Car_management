import datetime
import random
import string

from flask_login import UserMixin
from sqlalchemy.sql import func
from werkzeug.security import check_password_hash, generate_password_hash

from . import db


class User(db.Model, UserMixin):
    """_summary_
    This Python code defines a class `User` with attributes such as id, email, password, first_name,
    last_name, date_created, balance, subscription, active_status, spent_amount, and includes an
    `__init__` method that saves user data to a database and creates a card for the user.
    """

    def __init__(self, *args, **kwargs):
        """
        The function initializes a User object, saves it to the database, creates a card associated with
        the user, and prints messages at each step.
        """
        print("Saving user...")
        super(User, self).__init__(*args, **kwargs)
        print("User saved!")
        db.session.add(self)
        db.session.commit()

        print("Creating card...")
        self.create_card()
        print("Card created!")
        print("User created!")

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    last_name = db.Column(db.String(150))
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())
    balance = db.Column(db.Integer, default=0)
    subscription = db.Column(db.String(150), nullable=True)
    active_status = db.Column(db.String(150), default="Active")
    spent_amount = db.Column(db.Integer, default=0)

    # User Type:
    # 1. Admin
    # 2. Buyer
    # 3. Seller

    type = db.Column(db.String(150), nullable=True)
    cars = db.relationship("Car")

    def set_password(self, password):
        """
        The `set_password` function sets the password attribute of an object to a hashed version of the
        input password.

        :param password: The `password` parameter is the user-provided password that needs to be hashed
        before storing it in the `self.password` attribute
        """
        self.password = generate_password_hash(password)

    def check_password(self, password):
        """
        The function `check_password` compares a given password with a stored password hash to verify if
        they match.

        :return: The `check_password` method is returning the result of calling `check_password_hash` with
        the `self.password` and the `password` passed to the method.
        """
        return check_password_hash(self.password, password)

    def get_all_cars(self):
        return Car.query.filter_by(user_id=self.id).all()

    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"

    def get_cars_count(self):
        """
        The function `get_cars_count` returns the number of cars associated with a specific user ID.
        :return: The code snippet is returning the count of cars associated with a specific user ID. It
        is querying the database to find all cars that belong to the user with the given ID, and then
        returning the total count of those cars.
        """
        return len(Car.query.filter_by(user_id=self.id).all())

    def get_card_number(self):
        """
        The function retrieves a card number associated with a user and formats it by adding spaces
        every four characters.
        :return: The `get_card_number` method returns the card number associated with the user ID in a
        formatted manner. The card number is retrieved from the database using the `Card` model and the
        `user_id` attribute. The card number is then split into groups of 4 digits and joined with
        spaces before being returned.
        """
        number = Card.query.filter_by(user_id=self.id).first().card_number
        return " ".join([number[i : i + 4] for i in range(0, len(number), 4)])

    def get_card_expiry_date(self):
        return Card.query.filter_by(user_id=self.id).first().expiry_date

    def get_card_cvv(self):
        return Card.query.filter_by(user_id=self.id).first().cvv

    def get_card_holder(self):
        return Card.query.filter_by(user_id=self.id).first().card_holder

    def get_card_balance(self):
        """
        This function retrieves the balance of a card associated with a specific user ID.
        :return: The code is returning the balance of the card associated with the user ID. It is querying
        the database to find the card with the matching user ID and then returning the balance of that card.
        """
        return Card.query.filter_by(user_id=self.id).first().balance

    def get_user_discount_amount(self):
        """
        Calculate the discount rate for a user based on their total spent amount.

        The discount rate is determined as follows: for every 30,000 spent, a 1% (0.01) discount is applied.
        The total spent amount is divided by 30,000 to find the number of 30,000 increments in the total spent amount.
        This number is then multiplied by the discount rate per 30,000 increment to find the total discount rate.

        Returns:
            float: The final discount rate for the user.
        """
        discount_per_amount = 30_000
        discount_rate_per_amount = 0.01
        final_discount = 0
        final_discount = (
            self.spent_amount // discount_per_amount * discount_rate_per_amount
        )
        return final_discount

    def create_card(self):
        """
        Create a new card for the user.

        This method generates a unique 10-character ID and a 16-digit card number. 
        It also sets the card holder's name to the user's full name, and generates a random expiry date between 1 and 10 years from today. 
        The CVV is a random 3-digit number.

        The new card is then added to the database and associated with the user.

        Returns:
            Card: The newly created card.
        """

        # Generate a unique 10-character ID
        while True:
            id = "".join(random.choices(string.ascii_uppercase + string.digits, k=10))
            card = Card.query.filter_by(id=id).first()
            if not card:
                break

        # Generate a unique 16-digit card number
        while True:
            first_digit = str(random.choice(range(1, 10)))
            other_digits = "".join(random.choices(string.digits, k=15))
            card_number = first_digit + other_digits
            if not card:
                break

        # Set the card holder's name to the user's full name
        card_holder = self.get_full_name()

        # Generate a random expiry date between 1 and 10 years from today
        expiry_date = (
            datetime.date.today()
            + datetime.timedelta(
                days=random.randint(365, (365 * random.randint(1, 10)))
            )
        ).strftime("%m/%y")

        # Generate a random 3-digit CVV
        cvv = "".join(random.choices(string.digits, k=3))

        # Create the new card
        new_card = Card(
            id=id,
            card_number=card_number,
            card_holder=card_holder,
            expiry_date=expiry_date,
            cvv=cvv,
        )

        # Print a message indicating that the card is being created
        print(f"Creating card for {self.get_full_name()}...")

        # Print a message indicating that the card is being added to the user
        print(f"Adding card to {self.id}...")

        # Associate the new card with the user
        new_card.user_id = self.id

        # Add the new card to the database
        db.session.add(new_card)

        # Commit the changes to the database
        db.session.commit()

        # Return the newly created card
        return new_card

    def __str__(self) -> str:
        return f"{self.first_name} {self.last_name} <{self.email}>"


class Car(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String(150), nullable=True)
    # make types
    # 1. Toyota
    # 2. Honda
    # 3. BMW

    make = db.Column(db.String(150), nullable=True)
    model = db.Column(db.String(150), nullable=True)
    year = db.Column(db.String(150), nullable=True)
    price = db.Column(db.String(150), nullable=True)
    mileage = db.Column(db.String(150), nullable=True)
    color = db.Column(db.String(150), nullable=True)
    # transmission types
    # 1. Automatic
    # 2. Manual
    transmission = db.Column(db.String(150), nullable=True)
    # fuel type
    # 1. Petrol
    # 2. Diesel
    # 3. Electric
    # 4. Hybrid
    # 5. LPG
    fuel_type = db.Column(db.String(150), nullable=True)

    # engine types
    # 1. 1.0L
    # 2. 1.5L
    # 3. 2.0L

    engine = db.Column(db.String(150), nullable=True)
    description = db.Column(db.String(150), nullable=True)
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)

    status = db.Column(db.String(150), default="Available")
    bidding_amount = db.Column(db.String(150), nullable=True)
    current_bid = db.Column(db.String(150), nullable=True)

    def get_owner_name(self):
        return User.query.filter_by(id=self.user_id).first()

    def get_owner_id(self):
        return self.user_id


class CarRequest(db.Model):
    # ImmutableMultiDict([('title', 'BMW R10'), ('make', 'BMW'), ('model', 'RED'), ('year', '2020'), ('color', 'RED'), ('details', 'link-here')])
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=True)
    make = db.Column(db.String(150), nullable=True)
    model = db.Column(db.String(150), nullable=True)
    year = db.Column(db.String(150), nullable=True)
    color = db.Column(db.String(150), nullable=True)
    details = db.Column(db.String(150), nullable=True)
    date_created = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    status = db.Column(db.String(150), default="Pending")


class CarComponent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    component_name = db.Column(db.String(150), nullable=True)
    manufacturer = db.Column(db.String(150), nullable=True)
    details = db.Column(db.String(150), nullable=True)
    quantity = db.Column(db.String(150), nullable=True)

    date_created = db.Column(db.DateTime(timezone=True), default=func.now())

    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    status = db.Column(db.String(150), default="Requested")

    def get_all_current_user_components(self):
        return CarComponent.query.filter_by(user_id=self.id).all()


class Card(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    card_number = db.Column(db.String(150), nullable=True)
    card_holder = db.Column(db.String(150), nullable=True)
    expiry_date = db.Column(db.String(150), nullable=True)
    cvv = db.Column(db.String(150), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)

    def get_card_balance(self):
        return User.query.filter_by(id=self.user_id).first().balance

    def get_card_number(self):
        return self.card_number

    def __str__(self) -> str:
        return f"{self.card_holder} <{self.card_number}>"
